/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3;

import java.util.*; 


/**
 *
 * @author pauravpatel
 */
public class Lab3 {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        // TODO code application logic here

		CircularLinkedList<Integer> l =  new CircularLinkedList<Integer>();
		int n = 13;
		int k = 2;             
		for(int i =1; i<=n; i++) {     
                l.add(i);
            }
		
		// use the iterator to iterate around the list
		Iterator<Integer> iter = l.iterator();
		while(l.size !=1){
                    for(int i =0; i<k; i++){
                    iter.next(); 
                    }
                    iter.remove();
                    System.out.println(l);
                }
	
	}
 
    }
    

