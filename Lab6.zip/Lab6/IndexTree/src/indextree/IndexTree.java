/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package indextree;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;

/**
 *
 * @author pauravpatel
 */
public class IndexTree {

    // This is your root 
    private IndexNode root;

    // Make your constructor
    // complete the methods below
    // call your recursive add method
    public void add(String word, int lineNumber) {
        this.root = add(root, word, lineNumber);
    }
    //your recursive method for add
    // Think about how this works
    // When you add the word to the index, if it already exists, you want to 
    // add it to the IndexNode that already exists
    // otherwise make a new indexNode
    private IndexNode add(IndexNode root, String word, int lineNumber) {
        if (root == null) {
            root = new IndexNode(word);
            root.list.add(lineNumber);
            return root;
        }

        int compareVal = root.word.compareTo(word);

        if (compareVal == 0) {

            root.list.add(lineNumber);
            return root;
        } else if (compareVal < 0) {
            root.left = add(root.left, word, lineNumber);
            return root;
        } else {
            root.right = add(root.right, word, lineNumber);
            return root;
        }
    }
    
    // returns true if the word is in the index
    public boolean contains(String word) {
        if (root == null) {
            return false;
        }

        int compareVal = root.word.compareTo(root.word);

        if (compareVal == 0) {
            return true;
        } else if (compareVal < 0) {
            return contains(root.left.word);
        } else {
            return contains(root.right.word);
        }
    }

    // call your recursive method
    public void delete(String word) {
        this.root = delete(root, word);
    }

    // your recursive case
    // remove the word and all the entries for the word
    private IndexNode delete(IndexNode root, String word) {
        if (root == null) {
            return null;
        }

        int compareVal = root.word.compareTo(word);
        if (compareVal < 0) {
            root.left = delete(root.left, word);
            return root;
        } else if (compareVal > 0) {
            root.right = delete(root.right, word);
            return root;
        } else {
            if (root.left == null && root.right == null) {
                return null;

            } else if (root.left != null && root.right == null) {
                return root.left;
            } else if (root.left == null && root.right != null) {
                return root.right;
            } else {
                IndexNode current = root.right;
                while (current.left != null) {
                    current = current.left;
                }

                String temp = root.word;
                root.word = current.word;
                current.word = temp;

                root.right = delete(root.right, word);
                return root;
            }
        }
    }
    // prints all the words in the index in inorder order
    public void printIndex(IndexNode root, StringBuilder stringBuilder) {
        if (root == null) {
            return;
        }
        //System.out.println(root.word);
        printIndex(root.left, stringBuilder);
        stringBuilder.append(" ").append(root).append("\n ");
        printIndex(root.right, stringBuilder);
    }
    
    @Override
    public String toString() {
        StringBuilder s = new StringBuilder();
        printIndex(root, s);
        return s.toString();
    }

   
    public static void main(String[] args) {
        IndexTree index = new IndexTree();

        String fileName = "pg2240.txt";
        String line = null;
        BufferedReader bufferedReader;

        try {
            
            bufferedReader = new BufferedReader(new FileReader(fileName));
            int lineNumber = 0;
            while (bufferedReader.ready()) {
                line = bufferedReader.readLine();
                
                String[] words = line.split("\\s+");
                for (String word : words) {
                    word = word.replaceAll(":", "");
                    word = word.replaceAll(",", "");
                    index.add(word, lineNumber);
                }
                lineNumber++;
            }
            
            bufferedReader.close();
            System.out.println(index.toString());
        } catch (FileNotFoundException ex) {
            System.err.println("File not found");
        } // catch any other exception
        catch (Exception ex) {
            //ex.printStackTrace();
        }

    }
}
