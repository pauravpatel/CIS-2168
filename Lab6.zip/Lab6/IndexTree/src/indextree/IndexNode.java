/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package indextree;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author pauravpatel
 */
public class IndexNode {
    
	// The word for this entry
	String word;
	// The number of occurences for this word
	int occurences;
	// A list of line numbers for this word.
	List<Integer> list; 
	
	IndexNode left;
	IndexNode right;

    public IndexNode(String word) {
        this.word = word;
        this.occurences = 0;
        this.list = new ArrayList<>();
    }	
	// Complete This
	// return the word and the lines it appears on.
	// string must be one line
        @Override
	public String toString(){
		return word  +" "+ list ;
	}
	
}
