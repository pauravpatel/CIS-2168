/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.pkg2;

/**
 *
 * @author pauravpatel
 */
public class Guess {
    String g1;
    String g2;
    String g3;
    boolean TF;
    public Guess(String g1, String g2, String g3, boolean TF )
    {
        this.g1 = g1;
        this.g2 = g2;
        this.g3 = g3;
        this.TF = TF;
    }
    
    public String printResults()
    {
    if(TF == true)
    {
    return g1+","+g2+","+g3+",: "+"true";
    }
    else
    {
    return g1+","+g2+","+g3+",: "+"false";
    }
    }
    
}
