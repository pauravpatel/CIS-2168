/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.pkg2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author pauravpatel
 */
public class Lab2 {

    /**
     * @param args the command line arguments
     */
    
    
    ArrayList <String> list = new ArrayList();
    public static void main(String[] args) {
        new Lab2();
    }
       
    public boolean validate(String[] s) {
        if (Integer.parseInt(s[0])< Integer.parseInt(s[1]) && Integer.parseInt(s[1]) < Integer.parseInt(s[2])) {
            System.out.println("Yes, Thats a right sequence");
            return true;
            
        } else {
            System.out.println("No, Not a right sequence. Try Again");
            return false;
        }
    }

    public void Menu() {
        String s = "";
        String s1= ""; 
        
        do {
            try{
            Scanner kb = new Scanner(System.in);
            System.out.println("Enter 3 integers with space,to Guess type Guess,"
                    + " \n to see your previous guesses type previous, "
                    + "\n to quit game type Exit & to see game rules type Rules");
            s = kb.nextLine();
            if (s.equalsIgnoreCase("previous")) 
            { System.out.println(list);
            
            } 
            else if (s.equalsIgnoreCase("rules")) 
                
            { 
                System.out.println("Game rule is  Each number must be larger than the one before it.");
            } 
            else if (s.equalsIgnoreCase("guess")) 
            { 
                System.out.println("what is the game rule: "); 
                s1 = kb.nextLine();
            } 
            else if (s.equalsIgnoreCase("exit")) 
            {
                System.exit(0);
            } else 
            
            {
                String[] myWord = s.split(" ");
                Guess one = new Guess(myWord[0], myWord[1], myWord[2], validate(myWord));
                list.add(one.printResults());
            }
          }catch (Exception e) {
    System.err.println("Check User Input ");
                  }
            }while (s != "Exit");
    
    
          
      
        }

    public Lab2() {
    Menu();
    }

}


