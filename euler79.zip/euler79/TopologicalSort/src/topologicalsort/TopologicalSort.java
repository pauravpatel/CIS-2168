/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package topologicalsort;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;

/**
 *
 * @author pauravpatel
 */
public class TopologicalSort {
    
     private final HashMap<String, LinkedList<String>> inputG = new HashMap<>();

    private final HashMap<String, Integer> count = new HashMap<>();

    public static void main(String[] args) {

        String inputFile = "keylog.txt";

        TopologicalSort inst = new TopologicalSort();
        LinkedList<String> rootNodes = inst.Read(inputFile);
        inst.Topologicalsort(rootNodes);
    }

    public LinkedList<String> Read(String fileName) { // reads the file and keep track of nodes
        LinkedList<String> rootNodes = null;
        try {
            BufferedReader bufferedReader = new BufferedReader(new FileReader(fileName));
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                String[] s = line.split("");
                String parentNode = s[0];
                LinkedList<String> childrenList;

                if (inputG.containsKey(parentNode)) {
                    childrenList = inputG.get(parentNode);

                } else {

                    childrenList = new LinkedList<>();
                    inputG.put(parentNode, childrenList);
                }

                for (int i = 1; i < s.length; i++) {
                    childrenList.add(s[i]);

                    if (count.containsKey(s[i])) {
                        count.put(s[i], (count.get(s[i])) + 1);

                    } else {

                        count.put(s[i], 1);
                    }
                }
            }

            rootNodes = new LinkedList<>();
            Iterator<String> keyItr = inputG.keySet().iterator();
            System.out.print("Root Nodes: ");
            while (keyItr.hasNext()) {
                String key = keyItr.next();
                if (!count.containsKey(key)) {
                    rootNodes.add(key);
                    System.out.print(key);
                }
            }
            System.out.println();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return rootNodes;
    }

    public void Topologicalsort(LinkedList<String> rootNodes) { //Performs topological sort
        LinkedList<String> sortedList = new LinkedList<>();
        while (!rootNodes.isEmpty()) {
            String root = rootNodes.remove();
            sortedList.add(root);
            LinkedList<String> childrenList = inputG.get(root);

            if (childrenList != null) {
                Iterator<String> childItr = childrenList.iterator();

                while (childItr.hasNext()) {
                    String child = childItr.next();
                    int n = count.get(child).intValue() - 1;

                    if (n == 0) {
                        rootNodes.add(child);
                        count.remove(child);
                    } else {
                        count.put(child, n);
                    }
                }
            }

        }

        System.out.print("Shortest Passcode: ");
        while (sortedList.size() > 0) {
            System.out.print(sortedList.remove() + " ");
        }
    }
}  
    
    
    
    

    