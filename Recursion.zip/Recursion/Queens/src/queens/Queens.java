/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package queens;

/**
 *
 * @author pauravpatel
 */
public class Queens {
    
    
    
    public static final int s=8;

    // Blank out a chessboard. Use a hyphen to indicate no pieces are on
    // a space.
    public static void initBoard(char[][] board)
    {
        for (int i=0; i < s; i++)
            for (int j=0; j < s; j++)
                board[i][j] = '-';
    }

    // Display a chessboard to the terminal window. Just print out whatever
    // is in each position on the board.
    public static void display(char[][] board)
    {
        for (int i=0; i < s; i++)
        {
            for (int j=0; j < s; j++)
                System.out.print(board[i][j] + " ");
            System.out.println();
        }
        System.out.println();
    }

    // Check to see if a potential location (row, col) on the board is
    // "safe", which means that it cannot be taken by a queen already
    // on the board.
    public static boolean safe(char[][] board, int row, int col)
    {
        int i,j;

        // Check column
        for (i=0; i<s; i++)
            if (board[i][col] == 'Q')
                return false;

        // Check row
        for (j=0; j<s; j++)
            if (board[row][j] == 'Q')
                return false;

        // Check diagonal down and right
        for (i=row, j=col; i < s && j < s; i++, j++)
            if (board[i][j] == 'Q')
                return false;

        // Check diagonal up and left
        for (i=row, j=col; i >=0 && j >=0 ; i--, j--)
            if (board[i][j] == 'Q')
                return false;

        // Check diagonal up and right
        for (i=row, j=col; i >=0 && j < s; i--, j++)
            if (board[i][j] == 'Q')
                return false;

        // Check diagonal down and left
        for (i=row, j=col; i < s && j >=0 ; i++, j--)
            if (board[i][j] == 'Q')
                return false;

        // Must be safe
        return true;
    }

    // completeBoard fills in the board with a successful set of
    // queens and returns true if it can be done; otherwise, it leaves
    // the board unchanged and returns false
    public static boolean finishedBoard(char[][] board)
    {

        // Count queens, return if complete
        int numQueens = 0;
        for (int i=0; i < s; i++)
            for (int j=0; j < s; j++)
                if (board[i][j] == 'Q')
                    numQueens++;

        if (numQueens == s)
            return true;

        // If not eight queens, must be fewer: try to add another
        for (int i=0; i < s; i++)
            for (int j=0; j < s; j++)
                if (safe(board,i,j))
                {
                  board[i][j] = 'Q';
                    if (finishedBoard(board))
                        return true;
                    else
                        board[i][j] = '-';
                }
        
        // Failed to find solution
        return false;
    }

    public static void main(String[] args)
    {
        char[][] board = new char[s][s];
        initBoard(board);
        boolean success = finishedBoard(board);
        if (success)
        {
            System.out.println("Solved!");
            display(board);
        }
        else
        {
            System.out.println("Failed.");
        }
    }
}

    
        
        
        
    
    

