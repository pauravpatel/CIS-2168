/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package towerofhanoi;

import java.util.Scanner;

/**
 *
 * @author pauravpatel
 */
//public class TowerOfHanoi {

    /**
     * @param args the command line arguments
     * 
     */
    
    public class TowersOfHanoi {

   public void solve(int n, String p1, String p2, String p3) {
       if (n == 1) {
           System.out.println(p1 + " -> " + p3);
       } else {
           //When we need to move n-1 discs from the  pole1 to the  pole2, 
           //the  pole2 becomes pole3 and the pole3 becomes the  pole2. 
           solve(n - 1, p1, p3, p2); //Move (n-1) discs from pole1 to pole3.
           System.out.println(p1 + " -> " + p3);
           solve(n - 1, p2, p1, p3);  //Move the (n-1) discs from  pole2 to end pole1.
       }
   }
    public static void main(String[] args) {
        // TODO code application logic here

        TowersOfHanoi towersOfHanoi = new TowersOfHanoi();
        
       System.out.print("Enter number of discs: ");
       Scanner scanner = new Scanner(System.in);
       int discs = scanner.nextInt();
       
       towersOfHanoi.solve(discs, "1", "2", "3");
   }
    }
