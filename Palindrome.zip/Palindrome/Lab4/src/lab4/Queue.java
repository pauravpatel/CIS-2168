/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4;

import java.util.*;
/**
 *
 * @author pauravpatel
 */
public class Queue <E>{
    
    private Node<E> front;
	private Node<E> back;

	public Queue() {
		this.front = null;
		this.back  = null;
	}
		
	/*
	 * places element in the back of the Queue
        add (store) an item to the queue
	 */
	public void enqueue(E element){
            //Fill in
            
            Node<E> temp = new Node<E>(element); 
            if (front == null) {
            front = temp;
              }
            else {
            back.next = temp;
            }
            back = temp;
	}
	/*
	 * remove the front node of the queue and return it
	 */
	public E dequeue(){
		//Fill in;
                E element = peek(); 
                front = front.next; 
                if (front == null)
                back = null;
                return element; 	
	}

	/*
	 * Look at the front of the queue and return it, without removing
        PEEK:  Gets the element at the front of the queue without removing it.
	 */
	public E peek(){
		//Fill in;
                if (front == null)
        throw new NoSuchElementException();
                return front.data;	
	}
	
	//returns the size of the queue
	public int size(){
            int size = 0;   
        for(Node n = front; n!= null; n= n.next){
		size++;  
	}
        return size;  
}
}
    
    
