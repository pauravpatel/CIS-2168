/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4;

import java.util.*;

/**
 *
 * @author pauravpatel
 * 
 */
public class Stack <E> {
    LinkedList ll  = new LinkedList();
    
    private Node<E> top;

	public Stack() {
		this.top =null;
	}	
	/*
	 * places element on the top of the stack
        
        PUSH : To insert an item into the stack, Check for Stack overflow & Insert element into stack
         
	 */
	public void push(E element){	
            Node<E> temp = new Node<E>(element);
		//Fill in
               temp.next = top;
               top = temp;
   
	}
	
	/*
	 * remove the top node and return its contents
        POP : To remove an item from a stack, Check for Stack Underflow, Return top element of stack
	 */
	public E pop(){
		//Fill in;
                E result = peek(); 
                top = top.next; 
                return result;

	}
        
        //Checks if the queue is empty
       
        public boolean isEmpty() { 
            return top == null;
            }
	
	/*
	 * Look at the top element of the Stack and return it,
        without removing. 
        
        peek()
This function helps to see the data at the front of the queue. 
	 */
	public E peek(){  
		//Fill in;
                if (isEmpty())
throw new NoSuchElementException(); 
                return top.data;
	}
	
	//returns the size of the stack
	public int size(){
            int size = 0;
            for(Node n = top; n != null; n = n.next)
            {
                size++;
            }
		return size;  //replace
	}

}
    

