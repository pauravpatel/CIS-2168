/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4;

    import java.util.LinkedList;
    import java.util.Scanner;

/**
 *
 * @author pauravpatel
 */
    public class Lab4 {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        // TODO code application logic here

        LinkedList <String>ll = new LinkedList(); //linllist to store userinputs 
          
        String sentence;

        do{ 

        Scanner scan = new Scanner(System.in);
        
	Queue<Character> queue = new Queue <>();
	Stack<Character> stack = new Stack <>();
        
	int mismatches = 0;

	System.out.print("Enter your sentence or enter quit: ");//User input 
	sentence = scan.nextLine();
        
        if(sentence.equalsIgnoreCase("quit") ){ //for quiting program 
            String myList = " ";     // myLits is ro store palindrome words or string 
        int i = 0;
        
        for(String s: ll)   // this loop id for storing the correct palindrom 
        {
            i++;
            myList+= " "+s+"\n "; 
        }
        System.out.println(myList +"\n ");  // prints list of correct palindrome 
        System.exit(0);

        }
        
	for(int i = 0; i < sentence.length(); i++) {   // checks the user input for paloindrome 
            
	    char letter = sentence.charAt(i);
            
	    if(Character.isLetter(letter)) {
                
		letter = Character.toLowerCase(letter);
                
		stack.push(letter);//Add to Top , adds the words or sentence into stack
                
		queue.enqueue(letter);//Add to back, adds the words or sentence into queue
	    }
	}
	while((queue.size() != 0) && (stack.size() != 0)) { /*this loop is for the comparision of  
            size of both queue and stack */

	    if(!queue.dequeue().equals(stack.pop())) {

		mismatches++;  
	    }
	}
        
	if(mismatches == 0) {  // if words or string matches in both stack and queue it will print output accoring to that 
            ll.add(sentence);
	    System.out.println("\"" + sentence + "\" is a palindrome.");
	} else {
	    System.out.println("\"" + sentence + "\" is NOT a palindrome.");
	}
        
        }
      
        while(sentence != "quit"); //end of the do while loop 
   
}  }
    

