/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4;

/**
 *
 * @author pauravpatel
 */
public class Node <E> {
    
    E data;
	Node<E> next;
        
	public Node() {
            
		this.data = null;
		this.next = null;	
	}
	
	public Node(E e) {
		this.data = e;
		this.next = null;
	}

	public E getElement() {
		return this.data;
	}
	
	public void setElement(E element) {
		this.data= element;
    
}
}
