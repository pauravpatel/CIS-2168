/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dfs;

/**
 *
 * @author pauravpatel
 */
public class Dfs {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
      
        // TODO code application logic here
        Graph g = new Graph(6);
        g.addEdge(0, 1);
        g.addEdge(0, 2);
        g.addEdge(1, 2);
        g.addEdge(2, 0);
        g.addEdge(2, 3);
        g.addEdge(3, 3);

        System.out.println(" BFS(Breadth First Search)");
        g.bfs(0); // Start from vertex 0
        System.out.println();
        System.out.println();
        System.out.println(" DFS(Depth First Search)");
        g.dfs(2); // Start from veretex 2
        System.out.println();
    }

}  
        
    
    

