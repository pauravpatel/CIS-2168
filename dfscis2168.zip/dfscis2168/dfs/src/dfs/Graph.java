/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dfs;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

/**
 *
 * @author pauravpatel
 */
public class Graph {
    
    
        // TODO code application logic here
        //Lets create nodes as given as an example in the article
    public class adjList {

        Node head;
    }
    
    private int vertex; //Number of vertex
    private adjList[] arr; //Adjacency Lists

    public Graph(int v) {
        this.vertex = v;
        arr = new adjList[v];

        for (int i = 0; i < v; i++) {
            arr[i] = new adjList();
            arr[i].head = null;
        }
    }

    public void addEdge(int source, int dest) {
        Node n = new Node(dest);
        n.next = arr[source].head;
        arr[source].head = n;
    }

    public void bfs(int startVertex) {
        boolean[] visited = new boolean[vertex];
        Queue<Integer> q = new LinkedList();
        q.add(startVertex);
        while (q.isEmpty() == false) {
            int n = q.remove();
            System.out.print(" " + n);
            visited[n] = true;
            Node head = arr[n].head;
            while (head != null) {
                if (visited[head.dest] == false) {
                    q.add(head.dest);
                    visited[head.dest] = true;
                }
                head = head.next;
            }
        }
    }

    public void dfs(int startVertex) {
        boolean[] visited = new boolean[vertex];
        Stack<Integer> s = new Stack<>();
        s.push(startVertex);
        while (s.isEmpty() == false) {
            int n = s.pop();
            System.out.print(" " + n);
            visited[n] = true;
            Node head = arr[n].head;
            while (head != null) {
                if (visited[head.dest] == false) {
                    s.push(head.dest);
                    visited[head.dest] = true;

                }
                head = head.next;
            }
        }
    }

}
